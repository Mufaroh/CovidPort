package com.portal.CovidPortal.Reposi;
import com.portal.CovidPortal.Models.covid_tb;
import org.springframework.data.jpa.repository.JpaRepository;


public interface Cov19Repo extends JpaRepository<covid_tb, Long>
{
   // import



}
